package com.mycompany.assignment2;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RescueSystemTest {

    // Test rescue cost calculation
    @Test
    public void testRescueCost() {

        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "R001",
                "Leo",
                "Lion",
                "Kruger",
                "John",
                5,
                500,
                "Broken leg",
                2000,
                true
        );

        double expected = 9500;

        assertEquals(expected, rescue.calculateTotalCost());
    }

    // Test rescue priority
    @Test
    public void testRescuePriority() {

        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "R002",
                "Simba",
                "Lion",
                "Kruger",
                "Peter",
                3,
                400,
                "Serious injury",
                1000,
                true
        );

        assertEquals("Critical", rescue.getPriority());
    }

    // Test rescue status update
    @Test
    public void testStatusUpdate() {

        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "R003",
                "Max",
                "Leopard",
                "Pretoria",
                "David",
                2,
                300,
                "Injury",
                500,
                false
        );

        rescue.startRescue();

        assertEquals(
                RescueStatus.IN_PROGRESS,
                rescue.getStatus()
        );

        rescue.completeRescue();

        assertEquals(
                RescueStatus.COMPLETED,
                rescue.getStatus()
        );
    }

    // Test searching for a rescue case
    @Test
    public void testSearchRescueCase() {

        RescueSystem system = new RescueSystem();

        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "R004",
                "Rocky",
                "Rhino",
                "Limpopo",
                "Sarah",
                4,
                600,
                "Leg injury",
                1500,
                false
        );

        system.addRescueCase(rescue);

        RescueCase result = system.searchRescueCase("R004");

        assertNotNull(result);
        assertEquals("R004", result.getCaseId());
    }

    // Test duplicate Rescue Case IDs
    @Test
    public void testDuplicateCaseID() {

        RescueSystem system = new RescueSystem();

        InjuredAnimalRescue rescue1 = new InjuredAnimalRescue(
                "R005",
                "Jack",
                "Lion",
                "Kruger",
                "John",
                3,
                500,
                "Injury",
                1000,
                false
        );

        InjuredAnimalRescue rescue2 = new InjuredAnimalRescue(
                "R005",
                "Tom",
                "Leopard",
                "Limpopo",
                "Peter",
                4,
                600,
                "Injury",
                1500,
                false
        );

        assertTrue(system.addRescueCase(rescue1));

        assertFalse(system.addRescueCase(rescue2));
    }
}