package com.mycompany.assignment2;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        RescueSystem system = new RescueSystem();

        int choice = 0;

        while (choice != 6) {

            System.out.println("\n===== WILDLIFE SA RESCUE SYSTEM =====");
            System.out.println("1. Add Rescue Case");
            System.out.println("2. Search Rescue Case");
            System.out.println("3. Update Rescue Status");
            System.out.println("4. Display All Rescue Cases");
            System.out.println("5. Rescue Report");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            try {
                choice = input.nextInt();
                input.nextLine();

                switch (choice) {

                    case 1:
                        addCase(input, system);
                        break;

                    case 2:
                        searchCase(input, system);
                        break;

                    case 3:
                        updateStatus(input, system);
                        break;

                    case 4:
                        system.displayAllCases();
                        break;

                    case 5:
                        displayReport(system);
                        break;

                    case 6:
                        System.out.println("Thank you for using Wildlife SA.");
                        break;

                    default:
                        System.out.println("Invalid menu choice.");
                }

            } catch (Exception e) {

                System.out.println("Please enter a number.");
                input.nextLine();
            }
        }

        input.close();
    }

    // Add a new rescue case
    public static void addCase(Scanner input, RescueSystem system) {

        System.out.println("\n--- Add Rescue Case ---");

        System.out.print("Enter Rescue Case ID: ");
        String caseId = input.nextLine();

        if (caseId.trim().isEmpty()) {
            System.out.println("Case ID cannot be blank.");
            return;
        }

        if (system.searchRescueCase(caseId) != null) {
            System.out.println("Case ID already exists.");
            return;
        }

        System.out.print("Enter Animal Name: ");
        String animalName = input.nextLine();

        System.out.print("Enter Species: ");
        String species = input.nextLine();

        if (species.trim().isEmpty()) {
            System.out.println("Species cannot be blank.");
            return;
        }

        System.out.print("Enter Rescue Location: ");
        String location = input.nextLine();

        if (location.trim().isEmpty()) {
            System.out.println("Rescue location cannot be blank.");
            return;
        }

        System.out.print("Enter Assigned Ranger: ");
        String ranger = input.nextLine();

        if (ranger.trim().isEmpty()) {
            System.out.println("Assigned ranger cannot be blank.");
            return;
        }

        System.out.print("Enter Number of Rescue Days: ");
        int days = input.nextInt();

        if (days <= 0) {
            System.out.println("Rescue days must be greater than zero.");
            input.nextLine();
            return;
        }

        System.out.print("Enter Daily Care Cost: R");
        double dailyCost = input.nextDouble();

        if (dailyCost <= 0) {
            System.out.println("Daily care cost must be greater than zero.");
            input.nextLine();
            return;
        }

        System.out.println("\nSelect Rescue Type:");
        System.out.println("1. Injured Animal");
        System.out.println("2. Orphaned Animal");
        System.out.println("3. Endangered Species");
        System.out.print("Enter choice: ");

        int type = input.nextInt();
        input.nextLine();

        RescueCase rescueCase = null;

        if (type == 1) {

            System.out.print("Enter Injury Description: ");
            String injury = input.nextLine();

            System.out.print("Enter Veterinary Treatment Cost: R");
            double vetCost = input.nextDouble();

            System.out.print("Is Surgery Required? (yes/no): ");
            String surgery = input.next();

            boolean surgeryRequired =
                    surgery.equalsIgnoreCase("yes");

            rescueCase = new InjuredAnimalRescue(
                    caseId, animalName, species, location, ranger,
                    days, dailyCost, injury, vetCost, surgeryRequired);

        } else if (type == 2) {

            System.out.print("Enter Estimated Age in Months: ");
            int age = input.nextInt();

            System.out.print("Enter Feeding Cost: R");
            double feedingCost = input.nextDouble();

            System.out.print("Is Foster Care Required? (yes/no): ");
            String foster = input.next();

            boolean fosterRequired =
                    foster.equalsIgnoreCase("yes");

            rescueCase = new OrphanedAnimalRescue(
                    caseId, animalName, species, location, ranger,
                    days, dailyCost, age, feedingCost, fosterRequired);

        } else if (type == 3) {

            input.nextLine();

            System.out.print("Enter Conservation Classification: ");
            String classification = input.nextLine();

            System.out.print("Enter Security Cost: R");
            double securityCost = input.nextDouble();

            System.out.print("Is Specialist Team Required? (yes/no): ");
            String specialist = input.next();

            boolean specialistRequired =
                    specialist.equalsIgnoreCase("yes");

            rescueCase = new EndangeredSpeciesRescue(
                    caseId, animalName, species, location, ranger,
                    days, dailyCost, classification,
                    securityCost, specialistRequired);

        } else {

            System.out.println("Invalid rescue type.");
            return;
        }

        if (system.addRescueCase(rescueCase)) {
            System.out.println("Rescue case added successfully.");
        } else {
            System.out.println("Rescue case could not be added.");
        }
    }

    // Search for a rescue case
    public static void searchCase(Scanner input, RescueSystem system) {

        System.out.print("Enter Rescue Case ID: ");
        String id = input.nextLine();

        RescueCase rescueCase = system.searchRescueCase(id);

        if (rescueCase != null) {
            rescueCase.displaySummary();
        } else {
            System.out.println("Rescue case not found.");
        }
    }

    // Update rescue status
    public static void updateStatus(Scanner input, RescueSystem system) {

        System.out.print("Enter Rescue Case ID: ");
        String id = input.nextLine();

        System.out.println("1. Registered");
        System.out.println("2. In Progress");
        System.out.println("3. Completed");
        System.out.print("Choose new status: ");

        int choice = input.nextInt();
        input.nextLine();

        RescueStatus status;

        if (choice == 1) {
            status = RescueStatus.REGISTERED;
        } else if (choice == 2) {
            status = RescueStatus.IN_PROGRESS;
        } else if (choice == 3) {
            status = RescueStatus.COMPLETED;
        } else {
            System.out.println("Invalid status.");
            return;
        }

        if (system.updateStatus(id, status)) {
            System.out.println("Status updated successfully.");
        } else {
            System.out.println("Rescue case not found.");
        }
    }

    // Display the rescue report
    public static void displayReport(RescueSystem system) {

        System.out.println("\n========== RESCUE REPORT ==========");

        system.displayAllCases();

        System.out.println("\nTotal Rescue Cases: "
                + system.getNumberOfCases());

        System.out.println("Total Estimated Rescue Cost: R"
                + String.format("%.2f", system.getTotalCost()));

        System.out.println("====================================");
    }
}