package com.mycompany.assignment2;

public class EndangeredSpeciesRescue extends RescueCase {

    private String conservationClassification;
    private double securityCost;
    private boolean specialistTeamRequired;

    public EndangeredSpeciesRescue(String caseId, String animalName,
            String species, String rescueLocation, String assignedRanger,
            int rescueDays, double dailyCareCost,
            String conservationClassification, double securityCost,
            boolean specialistTeamRequired) {

        super(caseId, animalName, species, rescueLocation,
                assignedRanger, rescueDays, dailyCareCost);

        this.conservationClassification = conservationClassification;
        this.securityCost = securityCost;
        this.specialistTeamRequired = specialistTeamRequired;
    }

    @Override
    public double calculateTotalCost() {

        double total = (getRescueDays() * getDailyCareCost())
                + securityCost;

        if (specialistTeamRequired) {
            total = total + 8000;
        }

        return total;
    }

    @Override
    public String getPriority() {

        if (specialistTeamRequired) {
            return "Critical";
        } else {
            return "High";
        }
    }

    @Override
    public String getRescueType() {
        return "Endangered Species Rescue";
    }

    @Override
    public void displaySummary() {

        super.displaySummary();

        System.out.println("Conservation Classification: "
                + conservationClassification);

        System.out.println("Security Cost: R"
                + String.format("%.2f", securityCost));

        System.out.println("Specialist Team Required: "
                + specialistTeamRequired);
    }
}