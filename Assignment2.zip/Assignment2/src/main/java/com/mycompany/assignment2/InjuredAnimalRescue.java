package com.mycompany.assignment2;

public class InjuredAnimalRescue extends RescueCase {

    private String injuryDescription;
    private double veterinaryTreatmentCost;
    private boolean surgeryRequired;

    public InjuredAnimalRescue(String caseId, String animalName,
            String species, String rescueLocation, String assignedRanger,
            int rescueDays, double dailyCareCost,
            String injuryDescription, double veterinaryTreatmentCost,
            boolean surgeryRequired) {

        super(caseId, animalName, species, rescueLocation,
                assignedRanger, rescueDays, dailyCareCost);

        this.injuryDescription = injuryDescription;
        this.veterinaryTreatmentCost = veterinaryTreatmentCost;
        this.surgeryRequired = surgeryRequired;
    }

    @Override
    public double calculateTotalCost() {

        double total = (getRescueDays() * getDailyCareCost())
                + veterinaryTreatmentCost;

        if (surgeryRequired) {
            total = total + 5000;
        }

        return total;
    }

    @Override
    public String getPriority() {

        if (surgeryRequired) {
            return "Critical";
        } else {
            return "High";
        }
    }

    @Override
    public String getRescueType() {
        return "Injured Animal Rescue";
    }

    @Override
    public void displaySummary() {

        super.displaySummary();

        System.out.println("Injury Description: " + injuryDescription);
        System.out.println("Veterinary Treatment Cost: R"
                + String.format("%.2f", veterinaryTreatmentCost));
        System.out.println("Surgery Required: " + surgeryRequired);
    }
}
