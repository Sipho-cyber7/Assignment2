package com.mycompany.assignment2;

public abstract class RescueCase implements RescueOperations {

    private String caseId;
    private String animalName;
    private String species;
    private String rescueLocation;
    private String assignedRanger;
    private int rescueDays;
    private double dailyCareCost;
    private RescueStatus status;

    public RescueCase(String caseId, String animalName, String species,
                      String rescueLocation, String assignedRanger,
                      int rescueDays, double dailyCareCost) {

        this.caseId = caseId;
        this.animalName = animalName;
        this.species = species;
        this.rescueLocation = rescueLocation;
        this.assignedRanger = assignedRanger;
        this.rescueDays = rescueDays;
        this.dailyCareCost = dailyCareCost;
        this.status = RescueStatus.REGISTERED;
    }

    public String getCaseId() {
        return caseId;
    }

    public String getAnimalName() {
        return animalName;
    }

    public String getSpecies() {
        return species;
    }

    public String getRescueLocation() {
        return rescueLocation;
    }

    public String getAssignedRanger() {
        return assignedRanger;
    }

    public int getRescueDays() {
        return rescueDays;
    }

    public double getDailyCareCost() {
        return dailyCareCost;
    }

    public RescueStatus getStatus() {
        return status;
    }

    public void setStatus(RescueStatus status) {
        this.status = status;
    }

    public void startRescue() {
        status = RescueStatus.IN_PROGRESS;
    }

    public void completeRescue() {
        status = RescueStatus.COMPLETED;
    }

    public abstract double calculateTotalCost();

    public abstract String getPriority();

    public abstract String getRescueType();

    public void displaySummary() {

        System.out.println("------------------------------");
        System.out.println("Case ID: " + caseId);
        System.out.println("Rescue Type: " + getRescueType());
        System.out.println("Species: " + species);
        System.out.println("Assigned Ranger: " + assignedRanger);
        System.out.println("Rescue Priority: " + getPriority());
        System.out.println("Current Status: " + status);
        System.out.println("Total Rescue Cost: R"
                + String.format("%.2f", calculateTotalCost()));
    }
}