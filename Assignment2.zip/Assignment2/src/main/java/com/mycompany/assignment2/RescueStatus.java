package com.mycompany.assignment2;

public enum RescueStatus {
    REGISTERED,
    IN_PROGRESS,
    COMPLETED
}