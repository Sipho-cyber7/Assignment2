package com.mycompany.assignment2;

import java.util.ArrayList;

public class RescueSystem {

    // Stores all rescue cases
    private ArrayList<RescueCase> rescueCases;

    // Constructor
    public RescueSystem() {
        rescueCases = new ArrayList<>();
    }

    // Add a new rescue case
    public boolean addRescueCase(RescueCase rescueCase) {

        // Check if the ID already exists
        if (searchRescueCase(rescueCase.getCaseId()) != null) {
            return false;
        }

        rescueCases.add(rescueCase);
        return true;
    }

    // Search for a rescue case
    public RescueCase searchRescueCase(String caseId) {

        for (RescueCase rescueCase : rescueCases) {

            if (rescueCase.getCaseId().equalsIgnoreCase(caseId)) {
                return rescueCase;
            }
        }

        return null;
    }

    // Update the status of a rescue case
    public boolean updateStatus(String caseId, RescueStatus newStatus) {

        RescueCase rescueCase = searchRescueCase(caseId);

        if (rescueCase != null) {
            rescueCase.setStatus(newStatus);
            return true;
        }

        return false;
    }

    // Display all rescue cases
    public void displayAllCases() {

        if (rescueCases.isEmpty()) {
            System.out.println("No rescue cases found.");
            return;
        }

        for (RescueCase rescueCase : rescueCases) {

            System.out.println("------------------------------");
            System.out.println("Case ID: " + rescueCase.getCaseId());
            System.out.println("Rescue Type: "
                    + rescueCase.getRescueType());
            System.out.println("Species: "
                    + rescueCase.getSpecies());
            System.out.println("Rescue Location: "
                    + rescueCase.getRescueLocation());
            System.out.println("Assigned Ranger: "
                    + rescueCase.getAssignedRanger());
            System.out.println("Rescue Priority: "
                    + rescueCase.getPriority());
            System.out.println("Current Status: "
                    + rescueCase.getStatus());
            System.out.println("Total Rescue Cost: R"
                    + String.format("%.2f",
                            rescueCase.calculateTotalCost()));
        }
    }

    // Return the number of rescue cases
    public int getNumberOfCases() {
        return rescueCases.size();
    }

    // Calculate the total cost of all rescue cases
    public double getTotalCost() {

        double total = 0;

        for (RescueCase rescueCase : rescueCases) {
            total = total + rescueCase.calculateTotalCost();
        }

        return total;
    }
}
