package com.mycompany.assignment2;

public class OrphanedAnimalRescue extends RescueCase {

    private int estimatedAgeMonths;
    private double feedingCost;
    private boolean fosterCareRequired;

    public OrphanedAnimalRescue(String caseId, String animalName,
            String species, String rescueLocation, String assignedRanger,
            int rescueDays, double dailyCareCost,
            int estimatedAgeMonths, double feedingCost,
            boolean fosterCareRequired) {

        super(caseId, animalName, species, rescueLocation,
                assignedRanger, rescueDays, dailyCareCost);

        this.estimatedAgeMonths = estimatedAgeMonths;
        this.feedingCost = feedingCost;
        this.fosterCareRequired = fosterCareRequired;
    }

    @Override
    public double calculateTotalCost() {

        double total = (getRescueDays() * getDailyCareCost())
                + feedingCost;

        if (fosterCareRequired) {
            total = total + 2500;
        }

        return total;
    }

    @Override
    public String getPriority() {

        if (estimatedAgeMonths < 6) {
            return "Critical";
        } else {
            return "High";
        }
    }

    @Override
    public String getRescueType() {
        return "Orphaned Animal Rescue";
    }

    @Override
    public void displaySummary() {

        super.displaySummary();

        System.out.println("Estimated Age: "
                + estimatedAgeMonths + " months");

        System.out.println("Feeding Cost: R"
                + String.format("%.2f", feedingCost));

        System.out.println("Foster Care Required: "
                + fosterCareRequired);
    }
}