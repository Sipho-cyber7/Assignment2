package com.mycompany.assignment2;

public interface RescueOperations {

    void startRescue();

    void completeRescue();

    void displaySummary();
}